Validator functions reference
=============================

.. automodule:: ckan.logic.validators
   :members:
   :undoc-members:

.. automodule:: ckan.logic.converters
   :members:
   :undoc-members:

