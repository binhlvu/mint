# encoding: utf-8

import ckan.plugins as plugins


class ExampleIAuthFunctionsPlugin(plugins.SingletonPlugin):
    pass
