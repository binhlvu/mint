==============================
|javascript| sandbox reference
==============================

.. todo::

   Autodoc the |javascript| sandbox.
   This will probably require writing a custom Sphinx plugin.
