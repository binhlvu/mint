============================
Custom Jinja2 tags reference
============================

.. todo:: TODO
