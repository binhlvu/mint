:orphan:

.. Some common substitutions included by rst files in this directory.

.. |extension_dir| replace:: ``ckanext-example_theme``
.. |setup.py| replace:: ``ckanext-example_theme/setup.py``
.. |plugin.py| replace:: ``ckanext-example_theme/ckanext/example_theme/plugin.py``
.. |templates_dir| replace:: ``ckanext-example_theme/ckanext/example_theme/templates``
.. |index.html| replace:: ``ckanext-example_theme/ckanext/example_theme/templates/home/index.html``
.. |snippets_dir| replace:: ``ckanext-example_theme/ckanext/example_theme/templates/snippets``
.. |layout1.html| replace:: ``ckanext-example_theme/ckanext/example_theme/templates/home/layout1.html``

.. _Jinja2 docs: http://jinja.pocoo.org/docs/templates
