"use strict";

(function (jQuery) {

    jQuery.fn.greenify = function() {
      this.css( "color", "green" );
      return this;
    };

})(this.jQuery);
