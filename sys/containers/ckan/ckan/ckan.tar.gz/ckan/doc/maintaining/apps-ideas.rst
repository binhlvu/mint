============
Apps & Ideas
============

The old "Apps & Ideas" functionality to allow users to provide information on apps, ideas, visualizations, articles etc that are related to a specific dataset has been moved to a separate extension: `ckanext-showcase`_.

.. _ckanext-showcase: https://github.com/ckan/ckanext-showcase


