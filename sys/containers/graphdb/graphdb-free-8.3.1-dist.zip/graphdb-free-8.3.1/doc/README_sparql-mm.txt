The sparql-mm implementation is based on code by Thomas Kurz.
See LICENSE_sparql-mm.txt for the original license.